Projet réalisé par : Vincent BERNARDON et Thomas QUINTANA
Respectivement des groupes : D et C

- paramétrage par le premier joueur : fait

- sortie d’un joueur : fait

- détection automatique de la victoire : fait

- pose d’hexagones « corridors » : nous avons adapté ce système a notre façon en mettant en place des pions bloquants : 
                                        
            Il s'agit d'un jeu de Hex (avec quelques particularités):

            Les dites Particularités:

            - Le bouton Bloqueur:
                Permet de poser un block (vert) qu'il est impossible de retirer de quelque manière que ce soit, vous pouvez le 
                poser sur une case d'un autre joueur.
                Une fois le bloqueur posé, vous pouvez rejouez.

            - Le bouton Explosif: 
                Permet de poser une mine (grise) sur laquelle le premier jeton posé dessus va disparaitre, laissant une case
                vide, vous pouvez poser un explosif sur une case d'un autre joueur.
                Cela sert de ralentisseur.

- chat : fait